﻿using System;

namespace ShopOn.DataLayer
{
    public class Class1
    {
    }
}
