﻿using System;

namespace ShopOnTest
{
    public class Class1
    {
    }
}
