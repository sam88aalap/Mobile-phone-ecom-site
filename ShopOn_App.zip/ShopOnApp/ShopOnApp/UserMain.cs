﻿using ShopOn.BusinessLayer.Implementation;
using ShopOn.CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOnConsoleApp
{
    public class UserMain
    {
        private UserManager userManager = new UserManager();
        public void Main()
        {
            User user = new User();
            Console.WriteLine("Enter the username:");
            user.UserName = Console.ReadLine();
            Console.WriteLine("Enter the passsword");
            string password = Console.ReadLine();
            if (!string.IsNullOrEmpty(password))
            {
                user.UserPassword = userManager.PasswordEncrypter(password);
            }
        }
        

    }
}
