﻿using ShopOn.BusinessLayer.Contracts;
using ShopOn.BusinessLayer.Implementation;
using ShopOn.CommonLayer.Models;
using ShopOn.DataLayer.Contracts;
using ShopOn.DataLayer.Implementation;
using ShopOnEFLayer.Implementations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOnApp
{
    public class ProductMain
    {
        public void ProductMainMenu()
        {
            IProductRepository productRepository = new ProductRepositoryEFImpl();
            IProductManager productManager = new ProductManager(productRepository);

            bool flag = true;

            while (flag)
            {
                Console.WriteLine("Menu");
                Console.WriteLine("Choice 1: Add Product");
                Console.WriteLine("Choice 2: Display Products");
                Console.WriteLine("Choice 3: Display Product");
                Console.WriteLine("Choice 4: Update Product");
                Console.WriteLine("Choice 5: Remove Product");
                Console.WriteLine("Choice 6: Sort By Product Id");
                Console.WriteLine("Choice 7: Sort By Product Price");
                Console.WriteLine("Choice 8: Sort By Product Name");
                Console.WriteLine("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1: AddProduct(productManager);break;
                    case 2: DisplayProducts(productManager);break;
                    case 3: DisplayProductById(productManager);break;
                    case 4: UpdateProduct(productManager); break;
                    case 5: DeleteProduct(productManager); break;
                    case 6: SortByProductId(productManager); break;
                    case 7: SortByProductPrice(productManager); break;
                    case 8: SortByProductName(productManager); break;
                    case 9: flag = false; break;
                    default: 
                        Console.WriteLine("Invalid Choice. Please Re-enter the choice.");
                        break;
                }
                Console.WriteLine("Do you want to continue?y/n");
                string ch = Console.ReadLine();
                if((ch.ToLower()).Equals("n"))
                {
                    flag = false;
                }
             }

        }

        private void SortByProductName(IProductManager productManager)
        {
            var sortedProducts = productManager.SortByName();
            DisplayProductsData(sortedProducts);
        }

        private void SortByProductPrice(IProductManager productManager)
        {
            var sortedProducts = productManager.SortByPrice();
            DisplayProductsData(sortedProducts);
        }

        private void SortByProductId(IProductManager productManager)
        {
            var sortedProducts = productManager.SortById();
            DisplayProductsData(sortedProducts);

        }

        private void DeleteProduct(IProductManager productManager)
        {
            Console.WriteLine("Enter the Product Id to remove:");
            int searchId = Convert.ToInt32(Console.ReadLine());
            if (productManager.DeleteProduct(searchId))
            {
                Console.WriteLine("Product removed");
            }
            else
            {
                Console.WriteLine("Product not removed");
            }
        }

        private void UpdateProduct(IProductManager productManager)
        {
            Console.WriteLine("Enter the Product Id to update:");
            int searchId = Convert.ToInt32(Console.ReadLine());
            var updatedProduct = new Product();
            updatedProduct.ProductId = searchId;
            Console.WriteLine("Enter the Updated Product Name :");
            updatedProduct.ProductName = Console.ReadLine();
            Console.WriteLine("Enter the Updated Product Price :");
            updatedProduct.ProductPrice = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the Updated Product Availability :");
            updatedProduct.Availability = Console.ReadLine();
            Console.WriteLine("Enter the Updated Product Image URL :");
            updatedProduct.ImageUrl = Console.ReadLine();
            var result = productManager.UpdateProduct(updatedProduct);

            Console.WriteLine("Product Updated");
          
            //else
            //{
            //    Console.WriteLine("Product not updated");
            //}  
        }

        private void DisplayProductById(IProductManager productManager)
        {
            Console.WriteLine("Enter the Product Id to fetch:");
            int searchId = Convert.ToInt32(Console.ReadLine());
            var searchProduct = productManager.GetProduct(searchId);

            if (searchProduct == null)
            {
                Console.WriteLine($"Product not found");
            }
            else
            {
                Console.WriteLine("PID \t ProductName \t Price \t Availability \t ImageURL");
                Console.WriteLine("*****************************************************************");
                Console.WriteLine($"{searchProduct.ProductId} \t {searchProduct.ProductName} \t {searchProduct.ProductPrice} \t {searchProduct.Availability} " +
                    $"\t {searchProduct.ImageUrl}");
            }
        }

        private void AddProduct(IProductManager productManager)
        {
            string errMessage = string.Empty;

            Product product1 = new Product()
            {
                Availability = "y",
                ImageUrl = "nothing.jpg",
                ProductId = 501,
                ProductName = "Nothing",
                ProductPrice = 33000,
                CompanyId = 1001,
                CategoryId=2001
            };

            //Product product2 = new Product()
            //{
            //    Availability = "yes",
            //    ImageUrl = "coffemug.jpg",
            //    ProductId = 20,
            //    ProductName = "coffee mug",
            //    ProductPrice = 247
            //};

            //Product product3 = new Product()
            //{
            //    Availability = "yes",
            //    ImageUrl = "screencleaner.jpg",
            //    ProductId = 56,
            //    ProductName = "Apple Screen Cleaner",
            //    ProductPrice = 467
            //};

            //Product product4 = new Product()
            //{
            //    Availability = "yes",
            //    ImageUrl = "nurfgun.jpg",
            //    ProductId = 598,
            //    ProductName = "Nerf Gun",
            //    ProductPrice = 1437
            //};

            productManager.AddProduct(product1, out errMessage);
            //productManager.AddProduct(product2,out errMessage);
            //productManager.AddProduct(product3,out errMessage);
            //productManager.AddProduct(product4,out errMessage);

            if (string.IsNullOrEmpty(errMessage))
            {
                Console.WriteLine("Product added successfuly");
            }

            else
            {
                Console.WriteLine(errMessage);
            }

            /*int pid = 0;
            Console.WriteLine("Enter the Product Id :");
            if(int.TryParse(Console.ReadLine(), out pid))
            {
                product.ProductId = pid;
            }
            Console.WriteLine("Enter the Product Name :");
            product.ProductName = Console.ReadLine();
            Console.WriteLine("Enter the Product Price :");
            product.ProductPrice = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the Product Availability :");
            product.Availability = Console.ReadLine();
            Console.WriteLine("Enter the Product Image URL :");
            product.ImageUrl = Console.ReadLine();
            Console.WriteLine("*****************************************************************");

            try
            {
                if (productManager.AddProduct(product, out errMessage))
                {
                    Console.WriteLine("Product added successfuly");
                }

                else
                {
                    Console.WriteLine("Product not added");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }*/
        }

        private void DisplayProducts(IProductManager productManager)
        {
            var products = productManager.GetProducts();
            DisplayProductsData(products.ToList());
        }

        private static void DisplayProductsData(IEnumerable<Product> products)
        {
            Console.WriteLine("PID \t ProductName \t Price \t Availability \t ImageURL");
            Console.WriteLine("*****************************************************************");
            foreach (var product in products)
            {
                Console.WriteLine($"{product.ProductId} \t {product.ProductName} \t {product.ProductPrice} \t {product.Availability} " +
                    $"\t {product.ImageUrl}");
            }
        }
    }
}
