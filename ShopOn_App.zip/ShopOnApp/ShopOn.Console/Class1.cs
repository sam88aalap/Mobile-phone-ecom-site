﻿using System;

namespace ShopOn.Console
{
    public class Class1
    {
    }
}
