﻿using System;

namespace ShopOn.BusinessLayer
{
    public class Class1
    {
    }
}
