using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ShopOn.BusinessLayer.Contracts;
using ShopOn.BusinessLayer.Implementation;
using ShopOn.BusinessLayer.Utility;
using ShopOn.CommonLayer.Models;
using ShopOn.DataLayer.Contracts;
using ShoponCommon.CustomException;
using System.Collections.Generic;
using System.Linq;

namespace ShopOn.Test
{
    [TestClass]
    public class ShopOnBLUnitTest
    {
        private IProductManager productManager = null;
        private Mock<IProductRepository> productRepoMock = null;

        [TestInitialize]
        public void Init()
        {
            productRepoMock = new Mock<IProductRepository>();
            productManager = new ProductManager(productRepoMock.Object);
        }

        //[TestMethod]
        //public void AddProductTest()
        //{
        //    var message = string.Empty;
        //    var value = true;
        //    var product = new Product()
        //    {
        //        Availability = "yes",
        //        ImageUrl = "rccar.jpg",
        //        ProductId = 277,
        //        ProductName = "RC Car",
        //        ProductPrice = 2500
        //    };
        //    productRepoMock.Setup(x => x.InsertProduct(product, out message)).Returns(value);
        //    var actual = productManager.AddProduct(product, out message);
        //    Assert.IsTrue(actual);
        //}

        //[TestMethod]
        //[ExpectedException(typeof(InvalidProductException))]
        //public void AddAlreadyExistingProductTest()
        //{
        //    var message = string.Empty;
        //    var value = true;
        //    //Dictionary<int, Product> products = new Dictionary<int, Product>();
        //    var product = new Product()
        //    {
        //        Availability = "yes",
        //        ImageUrl = "rccar.jpg",
        //        ProductId = 277,
        //        ProductName = "Rc Drone Car",
        //        ProductPrice = 2500
        //    };
        //    productRepoMock.Setup(x => x.InsertProduct(product, out message)).Returns(value);
        //    var result = productManager.AddProduct(product, out message);
        //    var actualResult = productManager.AddProduct(product, out message);
        //}

        [TestMethod]
        public void GetProductsTest()
        {
            List<Product> products = new List<Product>()
            {
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "rccar.jpg",
                    ProductId = 247,
                    ProductName = "Rc Car",
                    ProductPrice = 2500
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "coffemug.jpg",
                    ProductId = 20,
                    ProductName = "coffee mug",
                    ProductPrice = 247
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "screencleaner.jpg",
                    ProductId = 56,
                    ProductName = "Apple Screen Cleaner",
                    ProductPrice = 467
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "nurfgun.jpg",
                    ProductId = 598,
                    ProductName = "Nerf Gun",
                    ProductPrice = 1437
                }
            };
            productRepoMock.Setup(x => x.GetProducts()).Returns(products);
            var actual = productManager.GetProducts().FirstOrDefault();
            var expected = new Product()
            {
                Availability = "yes",
                ImageUrl = "rccar.jpg",
                ProductId = 247,
                ProductName = "Rc Car",
                ProductPrice = 2500
            };
           
            Assert.IsNotNull(actual);
            Assert.AreEqual(expected.ProductId, actual.ProductId);
        }

        [TestMethod]
        public void GetProductByIdTest()
        {
            var id = 2;
            List<Product> products = new List<Product>()
            {
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "rccar.jpg",
                    ProductId = 247,
                    ProductName = "Rc Car",
                    ProductPrice = 2500
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "coffemug.jpg",
                    ProductId = 20,
                    ProductName = "coffee mug",
                    ProductPrice = 247
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "screencleaner.jpg",
                    ProductId = 56,
                    ProductName = "Apple Screen Cleaner",
                    ProductPrice = 467
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "nurfgun.jpg",
                    ProductId = 598,
                    ProductName = "Nerf Gun",
                    ProductPrice = 1437
                }
            };
            var result = new Product()
            {
                Availability = "yes",
                ImageUrl = "coffemug.jpg",
                ProductId = 20,
                ProductName = "coffee mug",
                ProductPrice = 247
            };
            productRepoMock.Setup(x => x.GetProductById(id)).Returns(result);
            var actual = productManager.GetProduct(id);
            var expected = new Product()
            {
                Availability = "yes",
                ImageUrl = "coffemug.jpg",
                ProductId = 20,
                ProductName = "coffee mug",
                ProductPrice = 247
            };

            Assert.AreEqual(actual.ProductId, expected.ProductId);
        }

        [TestMethod]
        public void GetProductByInvalidIdTest()
        {
            var id = 20;
            Product product = null;
            productRepoMock.Setup(x => x.GetProductById(id)).Returns(product);
            var actual = productManager.GetProduct(id);

            Assert.IsNull(actual);
        }

        [TestMethod]
        public void UpdateProductTest()
        {
            var id = 20;
            List<Product> products = new List<Product>()
            {
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "rccar.jpg",
                    ProductId = 247,
                    ProductName = "Rc Car",
                    ProductPrice = 2500
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "coffemug.jpg",
                    ProductId = 20,
                    ProductName = "coffee mug",
                    ProductPrice = 247
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "screencleaner.jpg",
                    ProductId = 56,
                    ProductName = "Apple Screen Cleaner",
                    ProductPrice = 467
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "nurfgun.jpg",
                    ProductId = 598,
                    ProductName = "Nerf Gun",
                    ProductPrice = 1437
                }
            };
            var product = new Product()
            {
                Availability = "yes",
                ImageUrl = "Coffemug.jpg",
                ProductId = 20,
                ProductName = "Clay Coffee Mug",
                ProductPrice = 147
            };
            productRepoMock.Setup(x => x.UpdateProduct(product)).Returns(true);
            var actual = productManager.UpdateProduct(product);

            Assert.IsTrue(actual);
        }

        [TestMethod]
        public void DeleteProductTest()
        {
            var id = 20;
            var product = new Product()
            {
                Availability = "yes",
                ImageUrl = "coffemug.jpg",
                ProductId = 20,
                ProductName = "coffee mug",
                ProductPrice = 247
            };
            productRepoMock.Setup(x => x.DeleteProduct(id)).Returns(true);
            bool actual = productManager.DeleteProduct(id);

            Assert.IsTrue(actual);
        }

        [TestMethod]
        public void SortByIdTest()
        {
            List<Product> products = new List<Product>()
            {
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "coffemug.jpg",
                    ProductId = 20,
                    ProductName = "coffee mug",
                    ProductPrice = 247
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "screencleaner.jpg",
                    ProductId = 56,
                    ProductName = "Apple Screen Cleaner",
                    ProductPrice = 467
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "rccar.jpg",
                    ProductId = 247,
                    ProductName = "Rc Car",
                    ProductPrice = 2500
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "nurfgun.jpg",
                    ProductId = 598,
                    ProductName = "Nerf Gun",
                    ProductPrice = 1437
                }
            };
            productRepoMock.Setup(x => x.GetProducts()).Returns(products);
            var expectedProductList = products;
            var actualProductList = products.ToList();
            actualProductList.Sort(new IdComparer());

            CollectionAssert.AreEqual(expectedProductList, actualProductList);
        }

        [TestMethod]
        public void SortByNameTest()
        {
            List<Product> products = new List<Product>()
            {            
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "screencleaner.jpg",
                    ProductId = 56,
                    ProductName = "Apple Screen Cleaner",
                    ProductPrice = 467
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "coffemug.jpg",
                    ProductId = 20,
                    ProductName = "coffee mug",
                    ProductPrice = 247
                },
                                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "nurfgun.jpg",
                    ProductId = 598,
                    ProductName = "Nerf Gun",
                    ProductPrice = 1437
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "rccar.jpg",
                    ProductId = 247,
                    ProductName = "Rc Car",
                    ProductPrice = 2500
                }
            };
            productRepoMock.Setup(x => x.GetProducts()).Returns(products);
            var expectedProductList = products;
            var actualProductList = products.ToList();
            actualProductList.Sort(new NameComparer());

            CollectionAssert.AreEqual(expectedProductList, actualProductList);
        }

        [TestMethod]
        public void SortByPriceTest()
        {
            List<Product> products = new List<Product>()
            {               
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "coffemug.jpg",
                    ProductId = 20,
                    ProductName = "coffee mug",
                    ProductPrice = 247
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "screencleaner.jpg",
                    ProductId = 56,
                    ProductName = "Apple Screen Cleaner",
                    ProductPrice = 467
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "nurfgun.jpg",
                    ProductId = 598,
                    ProductName = "Nerf Gun",
                    ProductPrice = 1437
                },
                new Product()
                {
                    Availability = "yes",
                    ImageUrl = "rccar.jpg",
                    ProductId = 247,
                    ProductName = "Rc Car",
                    ProductPrice = 2500
                }
            };
            productRepoMock.Setup(x => x.GetProducts()).Returns(products);
            var expectedProductList = products;
            var actualProductList = products.ToList();
            actualProductList.Sort(new PriceComparer());

            CollectionAssert.AreEqual(expectedProductList, actualProductList);
        }

    }
}
