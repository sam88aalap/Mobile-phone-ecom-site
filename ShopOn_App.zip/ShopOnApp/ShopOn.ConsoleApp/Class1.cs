﻿using System;

namespace ShopOn.ConsoleApp
{
    public class Class1
    {
    }
}
